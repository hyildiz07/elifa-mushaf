# İlk açılış ekranındaki hilali kaldırma (Play / APK sürümü)

## Sorun
Uygulama açılırken **iki splash** görünüyordu:
1. **Android'in kendisi** — `res/drawable-*/splash.png` dosyasından çiziyor (hilal + yıldız)
2. **Uygulamanın kendi splash'ı** — aynı hilal + "Elifa Mushaf" yazısı

Birincisi HTML'den kaldırılamaz — Android çiziyor, sayfa daha yüklenmemiş.
Kaldırmanın tek yolu Android projesindeki görseli değiştirmek.

## Çözüm
Bu klasördeki 5 `splash.png` **düz krem** (#F8EFD9) — üzerinde hiçbir şey yok.
Zemin rengiyle aynı olduğu için **Android'in açılış ekranı boş görünür.**
Hemen ardından uygulamanın kendi splash'ı (logo + yazı) gelir. **Tek splash.**

## Nasıl uygulanır
1. `ELIFA_TWA_PLAYSTORE.zip → 04-KAYNAK-PROJE/` klasörünü aç
2. Bu klasördeki dosyaları **üzerine yaz**:
   ```
   app/src/main/res/drawable-mdpi/splash.png
   app/src/main/res/drawable-hdpi/splash.png
   app/src/main/res/drawable-xhdpi/splash.png
   app/src/main/res/drawable-xxhdpi/splash.png
   app/src/main/res/drawable-xxxhdpi/splash.png
   ```
3. Yeniden derle:
   ```
   bubblewrap build
   ```
   (ya da `./gradlew bundleRelease`)
4. Aynı keystore ile imzalanır — `assetlinks.json` değişmez, parmak izi aynı kalır

## Uyarı
Bu **yalnız Play/APK sürümünü** düzeltir.
Chrome'a "ana ekrana ekle" ile kurulan PWA'da splash'ı Chrome üretir;
oraya müdahale edemeyiz. Onun için index.html'de iki splash'ı birebir
üst üste bindirdim (v160) — ikon kıpırdamaz, çift görüntü hissi olmaz.
