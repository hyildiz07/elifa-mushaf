/* ══════════════════════════════════════════════════════════════════
   ELIFA Mushaf — Service Worker (v143)

   ── ÖNCEKİ SÜRÜMDEKİ HATALAR ──
   1) SHELL_FILES'ta hem './' hem './index.html' vardı — AYNI DOSYA.
      Kurulumda 2 kez indiriliyordu. Sayfa da zaten indirmişti → 3 KEZ.
   2) fetch(u,{cache:'reload'}) → HTTP önbelleğini atlayıp yeniden indiriyordu.
   3) Her açılışta arka planda index.html'i (1,5 MB) TEKRAR çekiyordu.
   4) Güncelleme kontrolü iki 3,8 MB metni karşılaştırıyordu — çok pahalı.

   Sonuç: ilk açılışta ~4,5 MB gereksiz indirme → telefon boğuluyor,
   kullanıcı "iki sefer denemek" zorunda kalıyordu.

   ── YENİ TASARIM ──
   · Kurulumda SADECE küçük dosyalar. index.html BURADA YOK.
   · index.html ilk gezinme isteğinden yakalanır — EK İNDİRME YOK.
   · Sonraki açılışlar önbellekten ANINDA. Ağ beklenmez.
   · Güncelleme kontrolü: sadece version.json (birkaç yüz bayt), 6 saatte bir.
   · Fontlar ayrı dosya → paralel iner, önbelleğe alınır, offline çalışır.
   ══════════════════════════════════════════════════════════════════ */

const VERSION = 'elifa-mushaf-v174';
const SHELL  = 'elifa-shell-'  + VERSION;
const ASSETS = 'elifa-assets-' + VERSION;
const HTML   = './index.html';

const PRECACHE = [
  './manifest.json',
  './pwa_icon-192.png',
  './pwa_icon-512.png',
  './pwa_icon-maskable.png',
  './pwa_apple-180.png',
  './elif-mask.png',
  './existing_top_logo.png',
];

/* Türk mushafı metni — arka planda, sayfa açıldıktan SONRA indirilir.
   Böylece açılışı yavaşlatmaz ama offline'da da hazır olur. */
const ARKA_PLAN = ['./turk.json'];

const BYPASS = [
  'api.qurancdn.com', 'api.quran.com', 'quranicaudio.com',
  'download.quranicaudio.com', 'verses.quran.com', 'everyayah.com',
];

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(SHELL);
    await Promise.all(PRECACHE.map(async (u) => { try { await c.add(u); } catch (_) {} }));
    self.skipWaiting();
    /* Türk metnini ACELE ETMEDEN, arka planda al */
    setTimeout(async () => {
      const a = await caches.open(ASSETS);
      for (const u of ARKA_PLAN) { try { await a.add(u); } catch (_) {} }
    }, 8000);
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    const eski = keys.filter(k => k.startsWith('elifa-') && !k.endsWith(VERSION));
    await Promise.all(eski.map(k => caches.delete(k)));
    await self.clients.claim();

    /* ══ v152 — ZORLA YENİLE ══
       Eski service worker sayfayı önbellekten veriyordu ve kendini
       bırakmıyordu; Netlify'ye ne atılırsa atılsın telefonda eski sürüm
       kalıyordu. Artık: eski bir önbellek silindiyse, AÇIK OLAN sayfayı
       zorla yeniden yüklüyoruz. Yeni SHELL boş olduğu için sayfa ağdan
       taze iner. Kullanıcının hiçbir şey yapmasına gerek kalmaz.        */
    if (eski.length > 0) {
      const cs = await self.clients.matchAll({ type: 'window' });
      for (const c of cs) { try { await c.navigate(c.url); } catch (_) {} }
    }
  })());
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (BYPASS.some(h => url.hostname.includes(h))) return;

  // 1) SAYFA — önbellekten ANINDA, ağ beklenmez
  if (req.mode === 'navigate' || req.destination === 'document') {
    e.respondWith((async () => {
      const c = await caches.open(SHELL);
      const hit = await c.match(HTML);
      if (hit) { e.waitUntil(surumKontrol(c)); return hit; }
      try {
        const r = await fetch(req);
        if (r && r.ok) c.put(HTML, r.clone());
        return r;
      } catch (_) {
        return new Response(
          '<meta charset="utf-8"><h1 style="font-family:system-ui;padding:40px;text-align:center">'
          + 'Uygulama henüz indirilmedi.<br>Bir kez internete bağlanıp açın.</h1>',
          { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
      }
    })());
    return;
  }

  // 2) FONT / İKON — cache-first
  if (url.origin === self.location.origin) {
    e.respondWith((async () => {
      const c = await caches.open(url.pathname.includes('/f/') ? ASSETS : SHELL);
      const hit = await c.match(req);
      if (hit) return hit;
      try {
        const r = await fetch(req);
        if (r && r.ok) c.put(req, r.clone());
        return r;
      } catch (_) { return new Response('', { status: 504 }); }
    })());
    return;
  }

  // 3) DIŞ KAYNAK (jspdf) — cache-first
  e.respondWith((async () => {
    const c = await caches.open(ASSETS);
    const hit = await c.match(req);
    if (hit) return hit;
    try {
      const r = await fetch(req);
      if (r && (r.ok || r.type === 'opaque')) c.put(req, r.clone());
      return r;
    } catch (_) { return new Response('', { status: 504 }); }
  })());
});

let sonKontrol = 0;
async function surumKontrol(c) {
  const simdi = Date.now();
  if (simdi - sonKontrol < 60 * 1000) return;   // v151: 6 SAAT → 1 dakika.
  // Eskiden 6 saatti; üstelik version.json dosyası HİÇ YOKTU, o yüzden
  // kontrol hiçbir zaman başarılı olmadı. Artık dosya var ve ~35 bayt.
  sonKontrol = simdi;
  try {
    const v = await fetch('./version.json', { cache: 'no-store' });
    if (!v.ok) return;
    const d = await v.json();
    if (!d.version || d.version === VERSION) return;
    const r = await fetch(HTML, { cache: 'no-store' });
    if (r && r.ok) { await c.put(HTML, r.clone()); haberVer('yeni-surum'); }
  } catch (_) {}
}

function haberVer(tip) {
  self.clients.matchAll({ type: 'window' })
    .then(cs => cs.forEach(x => x.postMessage({ elifa: tip })));
}

self.addEventListener('message', (e) => {
  if (e.data === 'skipWaiting') self.skipWaiting();
});
