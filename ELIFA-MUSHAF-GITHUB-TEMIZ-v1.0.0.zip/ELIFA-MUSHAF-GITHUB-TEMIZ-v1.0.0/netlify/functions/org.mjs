/* ══════════════════════════════════════════════════════════════════
   ELIFA — /api/org   (Netlify Function)

   Birlikte özelliğinin sunucu tarafı. Uygulamadaki bkDemoApi ile
   BİREBİR aynı mantık — ama veri sunucuda durur, böylece link
   BAŞKA CİHAZLARDA da açılır.

   Depo: Netlify Blobs (ücretsiz, kurulum yok, veritabanı yok)

   Üyelik YOK. Kimlik doğrulama yok. İki anahtar var:
     · code       → katılım linki (herkese verilir)
     · adminToken → yönetici linki (yalnız kurucuda kalır)
   ══════════════════════════════════════════════════════════════════ */

import { getStore } from '@netlify/blobs';

const ALPHA = 'abcdefghijkmnpqrstuvwxyz23456789'; // karışan harfler yok (l,o,0,1)

function randCode(n) {
  let s = '';
  const buf = new Uint8Array(n);
  crypto.getRandomValues(buf);
  for (let i = 0; i < n; i++) s += ALPHA[buf[i] % ALPHA.length];
  return s;
}

/* Zikirde kişi başı sayı DIŞARI SIZMAZ — sadece toplam + isimler. */
function publicView(org, isAdmin) {
  const v = {
    type: org.type, title: org.title, zikirAd: org.zikirAd, hedef: org.hedef,
    dueDate: org.dueDate, adminName: org.adminName, createdAt: org.createdAt,
    items: org.items,
  };
  if (org.type === 'zikir') {
    const c = org.contributions || [];
    v.toplam = c.reduce((s, x) => s + (+x.amount || 0), 0);
    v.katilanlar = [...new Set(c.map(x => x.name).filter(Boolean))];
  }
  v.isAdmin = !!isAdmin;
  return v;
}

const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
});
const fail = (msg, status = 400) => json({ error: msg }, status);

/* Basit doğrulama — çöp veri yazılmasın */
function validOrg(o) {
  if (!o || typeof o !== 'object') return 'Geçersiz veri';
  if (o.type !== 'hatim' && o.type !== 'zikir') return 'Geçersiz tür';
  if (typeof o.title !== 'string' || o.title.length > 120) return 'Başlık geçersiz';
  if (o.adminName && String(o.adminName).length > 60) return 'İsim çok uzun';
  if (o.type === 'hatim') {
    if (!Array.isArray(o.items) || o.items.length < 1 || o.items.length > 30)
      return 'Cüz listesi geçersiz';
  } else {
    if (!(+o.hedef > 0) || +o.hedef > 100000000) return 'Hedef geçersiz';
    if (!o.zikirAd || String(o.zikirAd).length > 80) return 'Zikir adı geçersiz';
  }
  return null;
}

export default async (req) => {
  if (req.method !== 'POST') return fail('Yalnız POST', 405);

  let p;
  try { p = await req.json(); } catch { return fail('Gövde okunamadı'); }
  if (!p || !p.action) return fail('İşlem belirtilmedi');

  const store = getStore({ name: 'elifa-birlikte', consistency: 'strong' });

  /* ── CREATE ── */
  if (p.action === 'create') {
    const bad = validOrg(p.org);
    if (bad) return fail(bad);

    const code = randCode(6);
    const adminToken = randCode(12);
    const org = {
      type: p.org.type,
      title: String(p.org.title || '').slice(0, 120),
      adminName: String(p.org.adminName || '').slice(0, 60),
      dueDate: p.org.dueDate || null,
      zikirAd: p.org.zikirAd ? String(p.org.zikirAd).slice(0, 80) : undefined,
      hedef: p.org.hedef ? +p.org.hedef : undefined,
      items: (p.org.items || []).map(i => ({
        no: +i.no, name: '', status: 'bos', ts: 0,
      })),
      contributions: [],
      code, adminToken, createdAt: Date.now(),
    };
    await store.setJSON(code, org);
    await store.set('a_' + adminToken, code);      // yönetici anahtarı → kod
    return json({ code, adminToken });
  }

  /* ── kod çöz ── */
  let code = p.code;
  if (!code && p.admin) code = await store.get('a_' + p.admin, { type: 'text' });
  if (!code) return fail('Organizasyon bulunamadı', 404);

  const org = await store.get(code, { type: 'json' });
  if (!org) return fail('Organizasyon bulunamadı', 404);

  const isAdmin = !!p.admin && p.admin === org.adminToken;
  const save = () => store.setJSON(code, org);

  /* ── GET ── */
  if (p.action === 'get') {
    return json({ org: publicView(org, isAdmin), code });
  }

  /* ── CLAIM (cüz al) ── */
  if (p.action === 'claim') {
    const it = (org.items || []).find(i => i.no === +p.no);
    if (!it || it.status !== 'bos')
      return fail('Bu cüz az önce başkası tarafından alındı');
    it.status = 'alindi';
    it.name = String(p.name || '').slice(0, 60);
    it.ts = Date.now();
    await save();
    return json({ org: publicView(org, isAdmin), code });
  }

  /* ── RELEASE (cüzü bırak) ── */
  if (p.action === 'release') {
    const it = (org.items || []).find(i => i.no === +p.no);
    if (!it || it.status !== 'alindi')
      return fail('Sadece alınmış (henüz okunmamış) cüz bırakılabilir');
    it.status = 'bos'; it.name = ''; it.ts = Date.now();
    await save();
    return json({ org: publicView(org, isAdmin), code });
  }

  /* ── COMPLETE (okundu işaretle) ── */
  if (p.action === 'complete') {
    const it = (org.items || []).find(i => i.no === +p.no);
    if (!it || it.status === 'bos') return fail('Bu cüz henüz alınmamış');
    it.status = 'okundu'; it.ts = Date.now();
    await save();
    return json({ org: publicView(org, isAdmin), code });
  }

  /* ── CONTRIBUTE (zikir payı ekle) ── */
  if (p.action === 'contribute') {
    const n = +p.amount;
    if (!(n > 0) || n > 10000000) return fail('Geçersiz sayı');
    org.contributions = org.contributions || [];
    if (org.contributions.length > 5000) return fail('Bu niyet çok kalabalık');
    org.contributions.push({
      name: String(p.name || '').slice(0, 60), amount: n, ts: Date.now(),
    });
    await save();
    return json({ org: publicView(org, isAdmin), code });
  }

  /* ── ADMINSET (yönetici düzeltme) ── */
  if (p.action === 'adminSet') {
    if (!isAdmin) return fail('Yetki yok', 403);
    const it = (org.items || []).find(i => i.no === +p.no);
    if (it) {
      it.status = p.status;
      if (p.status === 'bos') it.name = '';
      it.ts = Date.now();
    }
    await save();
    return json({ org: publicView(org, true), code });
  }

  return fail('Bilinmeyen işlem');
};

export const config = { path: '/api/org' };
