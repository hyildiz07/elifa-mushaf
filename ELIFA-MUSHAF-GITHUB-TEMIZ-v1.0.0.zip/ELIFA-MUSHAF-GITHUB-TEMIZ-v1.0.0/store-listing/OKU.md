# PLAY STORE GÖRSELLERİ

Bu görseller **gerçek uygulamadan** alındı — mockup değil.
Uygulama başsız bir tarayıcıda (Chromium) açıldı, sürüm **170**,
saray teması, Türk mushafı, Uthman Taha Nesih hattı.

## 1-PLAY-GORSELLERI-telefon/  → Play'e BUNLARI yükle
1080×2400 · 8 adet · başlık + açıklama yazılı, lacivert-altın marka kapağı

| Sıra | Ekran | Başlık |
|---|---|---|
| 01 | Test modu | Ezberini test et |
| 02 | Ezber takibi | Tekrarı uygulama hatırlar |
| 03 | Hatim | Hatim, tek linkle |
| 04 | Latin okunuş | Latin okunuş |
| 05 | Okuma | Türk mushafı · Diyanet imlâsı |
| 06 | Toplu zikir | Toplu zikir |
| 07 | Hat & mushaf | İki mushaf, dört hat |
| 08 | Ana ekran | Ücretsiz. Reklamsız. Üyeliksiz. |

**İlk 3'ü listede önizleme olarak çıkar** — o yüzden en güçlüler başa alındı.
Uygulamanın adı ezber vaat ediyor ("Kolay Hafızlık"), bu yüzden 1. sıra test modu.

## 2-PLAY-GORSELLERI-tablet/  → tablet sekmesine
2560×1600 · 8 adet · aynı sıra

## 3-HAM-EKRANLAR/  → yazısız, çıplak ekran görüntüleri
Sosyal medya, web sitesi, sunum için. Telefon 1080×2400 · tablet 2560×1600

## Notlar
- Hatim ve zikir ekranlarındaki isimler ve ilerleme **temsilîdir** (Play kuralı:
  ekran görüntüsü uygulamanın gerçek arayüzünü göstermeli — gösteriyor).
- Tablet görselleri **yatay** çekildi; v168–170'te tablet yatayda okuma alanı
  tam ekrana yayılıyor ve punto ekranla ölçekleniyor.
- Latin okunuş görselinde v164 onarımı görünür: `tenzîlel'azîzirrahîm`,
  `lâ yü'minûn` — hemze ve ayn kesme işaretleri yerinde.
