# GOOGLE PLAY — MAĞAZA KAYDI (kopyala-yapıştır)

Uygulama: **Kolay Hafızlık: Kuran Ezberle**
Paket: `com.elifaplatform.mushaf` · Sürüm 1.0.0
Geliştirici adı (Play'de görünecek): **Elifa Platform**

---

## 1 · UYGULAMA ADI  *(sınır 30)*

```
Kolay Hafızlık: Kuran Ezberle
```
*29 karakter*

---

## 2 · KISA AÇIKLAMA  *(sınır 80 — bu alan sıralamaya girer)*

```
Hafızlık takibi, tekrar sistemi, hatim ve cüz paylaşımı. Reklamsız, üyeliksiz.
```
*77 karakter*

**Yedek:**
```
Kuran ezberle: test modu, aralıklı tekrar, hatim & cüz paylaşımı. Reklamsız.
```
*75 karakter*

---

## 3 · UZUN AÇIKLAMA  *(sınır 4000)*

```
Kolay Hafızlık — Kur'ân-ı Kerîm ezberleme ve hâfızlık uygulaması

Ücretsiz. Reklamsız. Üyeliksiz. Ticarî beklenti yok.

━━━━━━━━━━━━━━━━━━━━━━━━

🧠 HÂFIZLIK VE EZBER

Ezber, tekrarla olur. Uygulama tekrarı sizin yerinize takip eder.

• Test modu — âyetler gizlenir, siz ezberden okursunuz
• Takıldığınız kelimeye dokunun, sadece o kelime açılsın
• Aralıklı tekrar — 1 gün, 3 gün, 1 hafta, 2 hafta, 1 ay
• Sabak · Sabkî · Manzil — klasik hâfızlık usulü
• Kelime seçimi — âyetin sadece üç kelimesini seçip tekrar tekrar dinleyin
• Âyet tekrarı (1–20 kez) ve hız ayarı (0.7× – 1.5×)

━━━━━━━━━━━━━━━━━━━━━━━━

🎧 KELİME SENKRONLU KIRAAT

Kâri okurken okuduğu kelime vurgulanır. Gözünüz metinden ayrılmaz —
ezberin en zor kısmı olan "göz–kulak eşleşmesi" kendiliğinden kurulur.

• Onlarca kâri: Alafasy, Husary, Abdulbasit, Minshawi…
• Âyet birleştirme (1+2, 1+2+3)
• Çevrimdışı indirme — uçakta, metroda, serviste dinleyin

━━━━━━━━━━━━━━━━━━━━━━━━

📖 TAM MUSHAF, DOĞRULANMIŞ METİN

114 sûre, 6236 âyet. Metin, Tanzil (Medine standardı) ile harf harf
karşılaştırılarak doğrulanmıştır. Her sûrenin âyet sayısı standart
Hafs sayımıyla birebir uyuşur.

İki mushaf:
• Medine (Uthmanî) — hac ve umrede alıştığınız yazım
• Türk (Diyanet) — Türkiye'de basılan mushafın yazımı

Üç hat:
• Osman Taha Medine Hattı — Medine mushafını yazan hattatın yazısı
• Elifa Mushaf Nesih — ferah, göz yormayan
• Nesih (Sade) — küçük ekranlar için

━━━━━━━━━━━━━━━━━━━━━━━━

🤲 HATİM VE CÜZ PAYLAŞIMI — TEK LİNKLE

30 cüzü tek linkle paylaşın. Karşı tarafın uygulama kurması gerekmez,
üyelik yok, hesap yok.

• Hatim başlatın, katılım linkini gruba atın
• Herkes linke basar, cüzünü seçer, adını yazar
• Okuyunca "Okudum" der — herkes anında görür
• Yönetici olarak takip edin, hatırlatma gönderin
• Hatim bitince PDF raporu indirin — okuyanların isimleriyle

━━━━━━━━━━━━━━━━━━━━━━━━

📿 TOPLU ZİKİR

Ortak hedef belirleyin: 1000 salavat, 313 Âyetü'l-Kürsî…

• Tesbih halkasına dokunarak sayın
• Payınızı ortak hedefe ekleyin
• Kimin kaç okuduğu GÖRÜNMEZ — sadece toplam görünür
• Niyet halis, sayı gizli

━━━━━━━━━━━━━━━━━━━━━━━━

✈️ ÇEVRİMDIŞI ÇALIŞIR

Kur'ân metni ve fontlar uygulamanın içinde. Uçak modunda açılır.
Sesi de önceden indirebilirsiniz.

━━━━━━━━━━━━━━━━━━━━━━━━

🔒 GİZLİLİK

Notlarınız, yer imleriniz, ezber kaydınız SADECE sizin telefonunuzda durur.
Hiçbir yere gönderilmez. Reklam yok. Analitik izleyici yok. Çerez yok.

Tek istisna: Hatim/zikir paylaşımına katılırsanız yazdığınız isim —
o da yalnızca linki bilen gruba görünür. Takma ad da yazabilirsiniz.

━━━━━━━━━━━━━━━━━━━━━━━━

✨ AYRICA

• Yer imleri, notlar, renkli işaretler
• Secâvend (durak) işaretleri renkli — anlamlarıyla
• Latin harflerle okunuş
• 16 tema — gece okumaları için koyu temalar
• Sayfa (1–604), cüz (1–30), sûre ile gezinme
• Yedekleme — telefon değişince kayıplar yok
• Uygulama içi kullanma kılavuzu — 11 bölüm, internetsiz

━━━━━━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━━━━━━

🤝 TEŞEKKÜR

Türk mushafında kullanılan Uthman Taha Naskh hattı, Risale-i Nur Library
(feyyaz.org) ekibi tarafından bu uygulamada kullanılmak üzere ücretsiz
olarak paylaşılmıştır. Kendilerine teşekkür ederiz.

━━━━━━━━━━━━━━━━━━━━━━━━

وَلَقَدْ يَسَّرْنَا ٱلْقُرْءَانَ لِلذِّكْرِ فَهَلْ مِن مُّدَّكِرٍ

"Andolsun ki biz, Kur'ân'ı öğüt alınsın diye kolaylaştırdık.
Öğüt alan yok mu?"  (Kamer 54/17)

elifaplatform.com
```

---

## 4 · KATEGORİ VE ETİKETLER

**Kategori:** Kitap ve Referans
*(alternatif: Yaşam Tarzı → Din ve maneviyat)*

**Etiketler:**
```
kuran, kuran-ı kerim, hafızlık, ezber, kuran ezberleme, mushaf,
hatim, cüz paylaşımı, kıraat, tecvid, salavat, zikir, tesbih
```

---

## 5 · GİZLİLİK POLİTİKASI URL'İ  *(zorunlu)*

```
https://mushaf.elifaplatform.com/gizlilik
```
✓ Canlı, doğrulandı.

---

## 6 · VERİ GÜVENLİĞİ FORMU (Data Safety)

⚠️ Bu form gizlilik politikasıyla **birebir uyuşmalı**, yoksa red yersin.

### "Uygulamanız kullanıcı verisi topluyor mu?"
→ **EVET**

### Toplanan tek veri türü:

| Alan | Cevap |
|---|---|
| Veri türü | **Kişisel bilgiler → Ad** |
| Toplanıyor mu? | Evet |
| Paylaşılıyor mu? | **Hayır** |
| Zorunlu mu? | **Hayır — isteğe bağlı** (yalnız hatim/zikir paylaşımına katılırsa) |
| Amaç | **Uygulama işlevi** (App functionality) |
| Aktarımda şifreleniyor mu? | **Evet** (HTTPS) |
| Kullanıcı silinmesini isteyebilir mi? | **Evet** — info@elifaplatform.com |

### "Hayır" işaretlenecekler (hepsi):
Konum · E-posta · Telefon · Kişiler · Fotoğraf/Video · Ses dosyaları ·
Dosyalar · Takvim · Uygulama etkinliği · Web geçmişi · Cihaz kimliği ·
Reklam kimliği · Satın alma geçmişi · Sağlık · Finansal bilgi · Mesajlar

### Ek sorular
- **Reklam kimliği kullanıyor mu?** → Hayır
- **Üçüncü taraf reklam ağı var mı?** → Hayır
- **Analitik var mı?** → Hayır
- **Bağımsız güvenlik denetiminden geçti mi?** → Hayır (bu normal, sorun değil)

---

## 7 · İÇERİK DERECELENDİRMESİ ANKETİ

| Soru | Cevap |
|---|---|
| Şiddet | Hayır |
| Cinsellik | Hayır |
| Küfür / argo | Hayır |
| Uyuşturucu, alkol, tütün | Hayır |
| Kumar / bahis | Hayır |
| Korku öğeleri | Hayır |
| **Kullanıcılar birbiriyle iletişim kurabiliyor mu?** | **HAYIR** |
| Kullanıcılar içerik paylaşabiliyor mu? | **HAYIR** |
| Kullanıcı konumu paylaşılıyor mu? | Hayır |
| Dijital satın alma | Hayır |

> **Neden "kullanıcılar iletişim kuramıyor"?**
> Uygulamada sohbet, mesaj, yorum, forum **yok**. Hatimde yalnızca
> bir isim ve cüz numarası görünür — bu bir iletişim kanalı değildir.
> Bu doğru cevap; ileride yorum eklersek formu güncelleriz.

**Beklenen sonuç:** Herkes (3+)

---

## 8 · EKRAN GÖRÜNTÜLERİ

`ELIFA_KILAVUZ_VE_PLAYSTORE.zip → ekran-goruntuleri/`

Telefon 1080×2400 · Tablet 2560×1600. **En az 2, en çok 8.**
İlk 3 tanesi listede önizleme olarak çıkar — en güçlüler başa.

Yeni isme göre **önerilen sıra** (ezber öne çekildi):

| # | Dosya | Neden |
|---|---|---|
| 1 | `06-test-modu` | **Ezber vitrini** — isim bunu vaat ediyor |
| 2 | `07-ezber-takibi` | Aralıklı tekrar sistemi |
| 3 | `03-ses-kelime-senkron` | Kelime senkronlu kıraat |
| 4 | `02-okuma-osman-taha` | Mushaf, Osman Taha hattı |
| 5 | `09-hatim-cuz-tablosu` | Hatim & cüz paylaşımı |
| 6 | `10-toplu-zikir-tesbih` | Toplu zikir |
| 7 | `04-turk-mushafi` | Türk mushafı imlâsı |
| 8 | `01-ana-ekran` | Ana ekran |

---

## 9 · SIRALAMA — NE ZAMAN NE YAPILACAK

1. ☐ Play Console → Uygulama oluştur (Ad: **Kolay Hafızlık: Kuran Ezberle**, Türkçe, Ücretsiz)
2. ☐ Üretim → Yeni sürüm → `ElifaMushaf-v1.0.0.aab` yükle
3. ☐ **Sürüm → Kurulum → Uygulama imzalama** → **SHA-256'yı kopyala, Hüseyin bana getirsin**
4. ☐ Ben `assetlinks.json`'a ikinci parmak izini eklerim → Netlify'ye atarsın
5. ☐ Mağaza kaydı: yukarıdaki metinler + ekran görüntüleri + ikon
6. ☐ Gizlilik URL'i
7. ☐ Veri güvenliği formu (bölüm 6)
8. ☐ İçerik derecelendirmesi (bölüm 7)
9. ☐ Ülke seçimi (Türkiye + Almanya + tüm ülkeler önerilir)
10. ☐ İncelemeye gönder → 1–7 gün

> **3. ve 4. adım atlanırsa** Play'den inen uygulamada adres çubuğu görünür.
> Bu, TWA'da en sık yapılan hatadır.
