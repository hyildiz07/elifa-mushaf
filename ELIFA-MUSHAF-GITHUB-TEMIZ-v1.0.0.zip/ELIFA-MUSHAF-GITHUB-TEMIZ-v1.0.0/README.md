# Elifa Mushaf

GitHub-safe source package for the Elifa Mushaf web app and Android Trusted Web Activity.

## Repository layout

- Repository root: deployable Netlify/PWA site
- `netlify/functions/`: serverless functions
- `android/`: Android TWA source project
- `brand/`: public brand assets
- `store-listing/`: Play Store text and public screenshots

## Netlify deployment

Connect this repository to Netlify. The root `netlify.toml` publishes the repository root and uses `netlify/functions`.

## Android debug build

```bash
cd android
./gradlew assembleDebug
```

## Android release signing

Signing files and passwords are intentionally excluded from this repository.

1. Copy `android/keystore.properties.example` to `android/keystore.properties`.
2. Point `storeFile` to the private keystore stored outside the repository.
3. Fill in the private passwords locally.
4. Build with `./gradlew bundleRelease`.

Alternatively, set these environment variables:

- `ELIFA_KEYSTORE_PATH`
- `ELIFA_KEYSTORE_PASSWORD`
- `ELIFA_KEY_ALIAS`
- `ELIFA_KEY_PASSWORD`

## Security

Never commit keystores, password files, `.env` files, APKs, AABs, or tester lists. Private signing material is maintained separately in the secure Google Drive key vault.
