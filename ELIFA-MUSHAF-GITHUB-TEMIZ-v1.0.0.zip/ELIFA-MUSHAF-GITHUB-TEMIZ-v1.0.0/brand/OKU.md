# ELİFA — MARKA KİMLİĞİ

Bu klasör markanın **tek doğru kaynağı**. Yeni bir görsel lazım olduğunda
`1-vektor/elifa-logo.svg` dosyasından üret — bir daha bitmap büyütme.

---

## RENKLER

| Rol | Kod | Kullanım |
|---|---|---|
| **Lacivert (koyu)** | `#061B36` | zemin gradyanının altı |
| **Lacivert (açık)** | `#0D3158` | zemin gradyanının üstü · ana marka rengi |
| **Altın (çerçeve)** | `#C99A35` | çerçeve, ayraç çizgileri |
| **Altın (yazı)** | `#E8C86A` | başlıklar, vurgu |
| **Krem (logo)** | `#F5ECD2` | hilâl ve yıldız |
| **Parıltı** | `#FFFDF4` | yıldızın çekirdeği |
| **Kâğıt (zemin)** | `#F8EFD9` | uygulamanın açılış zemini · `manifest.background_color` |

**Zemin gradyanı:** üstten alta `#0D3158` → `#061B36` (dikey)

---

## YAZI TİPİ

**Lora** — tek resmî font. Başlık, alt başlık, gövde: hepsi Lora.
Ağırlıklar: Regular · Medium · SemiBold · Bold
Arapça metin için ayrı: KFGQPC Hafs (Medine) · Uthman Taha Naskh (Türk)

---

## LOGO

Hilâl + 8 ışınlı yıldız. Geometrisi kesin:

**Hilâl** — dış yarıçap 182 · iç 177,74 · merkez kayması 6,74
- sırt kalınlığı 11 = çapın **%3,0**'ı
- boynuz noktaları (117,1 · ±139,4) → **açıklık 100°**
- −45° döndürülmüş → boynuzlar sağ üst çaprazda, yıldızın üst ve sağ ışınlarına yaklaşır

**Yıldız** — 8 ışın, düz kenarlı sivri iğne (üçgen dilim)
- 4 kardinal L=132 · 4 çapraz L=82 (%62)
- hilâlin **tam merkezinde** · merkezde yumuşak parıltı (radyal gradyan)

### Kullanım kuralları
- Logo **döndürülmez**, eğilmez, gölge eklenmez
- Krem (`#F5ECD2`) koyu zemin üzerinde · lacivert (`#0D3158`) açık zemin üzerinde
- Etrafında en az **logo yüksekliğinin %20'si** kadar boşluk bırak
- İkon kullanımında motif kareyi **%64** oranında doldurur
- Maskeli (maskable) ikonda **%48** — Android kenarları kırpar

---

## KLASÖRLER

### 1-vektor/
- `elifa-logo.svg` ← **ASIL KAYNAK**, her şey bundan üretilir
- `logo-seffaf-256/512/1024/2048/4096.png` — krem, şeffaf zemin
- `logo-lacivert-seffaf-1024.png` — açık zeminler için

### 2-ikonlar/
Uygulama ikonları: 1024 · 512 · 192 · Apple 180 · maskable 512

### 3-magaza/
- `play-uygulama-simgesi-512x512.png` → Play Console → Uygulama simgesi
- `play-one-cikan-grafik-1024x500.png` → Play Console → Öne çıkan grafik

> Play bu iki boyutu **zorunlu** tutar, başkasını kabul etmez.
> İkon kareyi tam doldurur — Play kendi yuvarlak maskesini uygular.

### 4-sosyal/
- `kare-1080x1080.png` — Instagram, WhatsApp durumu
- `yatay-1920x1080.png` — YouTube kapağı, sunum, web başlığı

---

## NOT
TWA/Play uygulamasının **kendi simgesi APK'nın içindedir** — bu klasördeki
ikonu değiştirmek onu değiştirmez. AAB'nin yeniden derlenmesi gerekir.
